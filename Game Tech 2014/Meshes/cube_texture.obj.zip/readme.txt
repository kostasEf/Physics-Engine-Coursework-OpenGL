-- 3dvia.com   --

The zip file cube_texture.obj.zip contains the following files :
- readme.txt
- cube_texture.obj
- cube_texture.mtl
- Texture_door.jpg


-- Model information --

Model Name : OBJ Cube with Texture UV Map
Author : Rodd Halstead
Publisher : rhalstead

You can view this model here :
http://www.3dvia.com/content/B10B55A7B98B9DAF
More models about this author :
http://www.3dvia.com/rhalstead


-- Attached license --

A license is attached to the OBJ Cube with Texture UV Map model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
